#include<iostream>
using namespace std;
//basic code


